export const GET_PRODUCTS_SUCCESS = 'getProductsSuccess'
export const GET_PRODUCTS_FAIL = 'getProductsFail'


export const GET_PRODUCTS_DETAILS_REQUEST = 'getProductsRequest'
export const GET_PRODUCTS_DETAILS_SUCCESS = 'getProductsSuccess'
export const GET_PRODUCTS_DETAILS_FAIL = 'getProductsFail'
export const GET_PRODUCTS_DETAILS_RESET = 'getProductsReset'
